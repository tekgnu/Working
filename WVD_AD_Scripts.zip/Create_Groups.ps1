﻿#Creates the groups for WVD

$SecurityGroupName1 = "AccessFSLogix" 
$Description1 = "Will contain the Session Host Computer Objects that need " + `
    "to access the SOFS/S2D cluser to manage user profile containers"

$SecurityGroupName2 = "RDS-RemoteAppUsers" 
$Description2 = "Contains users that need access to RemoteApps Hosted Using WVD"

$SecurityGroupName3 = "RDSPooledDesktopUsers" 
$Description3 = "Contains users that need access to RemoteDesktop(Pooled) " + `
    "hosted using WVD"


New-ADGroup -Name $SecurityGroupName1 -SamAccountName $SecurityGroupName1 -GroupCategory Security `
    -GroupScope Global -Description $Description1

New-ADGroup -Name $SecurityGroupName2 -SamAccountName $SecurityGroupName2 -GroupCategory Security `
    -GroupScope Global -Description $Description2

New-ADGroup -Name $SecurityGroupName3 -SamAccountName $SecurityGroupName3 -GroupCategory Security `
    -GroupScope Global -Description $Description3