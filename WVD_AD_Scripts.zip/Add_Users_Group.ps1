﻿# Add users to the Group
$Identity = "RDS-RemoteAppUsers"
Add-ADGroupMember -Identity $Identity -Members @("RDSUser1", "RDSUser2", "RDSAdmin1")

$Identity = "RDS-PooledDesktopUsers"
Add-ADGroupMember -Identity $Identity -Members @("RDSUser3", "RDSUser4", "RDSAdmin1")
