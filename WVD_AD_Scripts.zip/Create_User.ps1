$name = "RDSUser4"
$UPN = $name + "@fictal.com"
$pass = ("bj7;vY^.J/E$" | ConvertTo-SecureString -AsPlainText -force)

Import-Module ActiveDirectory
New-ADUser -UserPrincipalName $UPN -AccountPassword $pass -DisplayName $name `
    -Name $name -ChangePasswordAtLogon $false `
    -Description "Test User for WVD" `
	-PasswordNeverExpires $true -Enabled $true


