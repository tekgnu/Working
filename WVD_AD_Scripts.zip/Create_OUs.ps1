﻿# Add OU Structure
$parentDC = 'DC=wvd1fictal,DC=onmicrosoft,DC=com'
$lev1 = "RDS"
$lev2 = "SessionHost"
$lev3a = "OnPrem"
$lev3b = "WVD"
$lev4a = "ClientOS"
$lev4b = "ServerOS"
$lev5a = "PersonalDesktopHostPool"
$lev5b = "PooledDesktopHostPool"
$lev5c = "RemoteAppHostPool"

# Add OU Structure

New-ADOrganizationalUnit -Name $lev1 -Path $parentDC -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev2 -Path "OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev3a -Path "OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev3b -Path "OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev4a -Path "OU=$lev3b,OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev4b -Path "OU=$lev3b,OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev5a -Path "OU=$lev4b,OU=$lev3b,OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev5b -Path "OU=$lev4b,OU=$lev3b,OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name $lev5c -Path "OU=$lev4b,OU=$lev3b,OU=$lev2,OU=$lev1,$parentDC" -ProtectedFromAccidentalDeletion $false
